package com.digitalwallet.ussd.domain;

public class RequestDTO {

    public String command;
    public String input;
}
