package com.digitalwallet.ussd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UssdApplicationTests {

	@Test
	void contextLoads() {
	}

}
